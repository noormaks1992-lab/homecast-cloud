import {ffmpegRuntime} from './ffmpeg-runtime.mjs';
import {createSegmentCache} from './segment-cache.mjs';
import {createChatEvents} from './chat-events.mjs';
import {viewerInfo} from './viewer-info.mjs';
import {createWatchAnalytics} from './watch-analytics.mjs';
import {createPro} from './pro.mjs';
import {capMaster,parseVideoInfo,epgXML} from './cap.mjs';
import {createQuality,channelList} from './quality.mjs';
import {createRoom,shortKey,equal,cookies} from './room.mjs';
import {Readable} from 'node:stream';
import {youtubeId,inspectDirect,inspectSource,discoverMajedServers,openPublic,readLimited,rewriteInput} from './sources.mjs';
import http from 'node:http';
import {readFile,writeFile,mkdir,rename,readdir,stat,unlink} from 'node:fs/promises';
import {createReadStream} from 'node:fs';
import {randomBytes,createHash,timingSafeEqual} from 'node:crypto';
import {spawn} from 'node:child_process';
import {createRequire} from 'node:module';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import {promisify} from 'node:util';
import {brotliCompress,gzip,constants as zlibConstants} from 'node:zlib';
const compressBrotli=promisify(brotliCompress),compressGzip=promisify(gzip);
process.umask(0o077);
const root=path.dirname(fileURLToPath(import.meta.url)),data=process.env.DATA_DIR||path.join(root,'data'),media=path.join(data,'media');
await mkdir(media,{recursive:true});
const token=()=>randomBytes(32).toString('hex'),hash=x=>createHash('sha256').update(x).digest('hex');
let state;try{state=JSON.parse(await readFile(path.join(data,'state.json'),'utf8'));}catch(e){if(e.code!=='ENOENT')throw e;state={owner:token(),viewer:token(),selection:null,history:[],invites:[]};await writeFile(path.join(data,'state.json'),JSON.stringify(state),{mode:0o600});}
// Retire browser-page selections: they never produced the requested fixed M3U.
if(['arena','page'].includes(state.selection?.kind)){state.selection={...state.selection,kind:'url'};delete state.selection.embedUrl;state.stopped=true;}
await writeFile(path.join(data,'owner-link.txt'),'افتح عنوان موقع دشوف وأضف إليه هذا الجزء لتسجيل دخول المالك. لا تشاركه:\n/#admin='+state.owner+'\n',{mode:0o600});
let writeQueue=Promise.resolve();function persist(){const text=JSON.stringify(state);writeQueue=writeQueue.catch(()=>{}).then(async()=>{await writeFile(path.join(data,'state.tmp'),text,{mode:0o600});await rename(path.join(data,'state.tmp'),path.join(data,'state.json'));});return writeQueue;}
function equals(a,b){return typeof a==='string'&&a.length===b.length&&timingSafeEqual(Buffer.from(a),Buffer.from(b));}
const room=createRoom(state,persist),owner=req=>room.owner(req),access=(req,url)=>room.access(req,url);
const pro=createPro(state,persist),chatEvents=createChatEvents();
const watchAnalytics=createWatchAnalytics(state,persist);
function beginWatchAnalytics(){if(state.selection)watchAnalytics.beginBroadcast({id:String(state.selection.updatedAt||'legacy-current'),title:state.selection.title,startedAt:state.selection.updatedAt});}
if(state.selection)beginWatchAnalytics();
if(state.stopped)watchAnalytics.endBroadcast();
await persist();
const ffmpegConfig=await ffmpegRuntime(data),ffmpeg=ffmpegConfig.executable;
let stopping=false;const inputPort=Number(process.env.SERVER_PORT||process.env.PORT||3000);
state.channelNames=Array.isArray(state.channelNames)?state.channelNames.slice(0,2):['القناة الأولى','القناة الثانية'];
state.channelNames=state.channelNames.map((n,i)=>String(!n||['القناة الأولى','القناة الثانية'].includes(n)?['دشوف 1','دشوف 2 (HDR)'][i]:n).slice(0,60));
while(state.channelNames.length<2)state.channelNames.push('دشوف 2 (HDR)');
state.secondChannel??={selection:null,history:[],stopped:true};
async function createBroadcast(id,state,media){
 await mkdir(media,{recursive:true});
const quality=createQuality();const analytics=id==='1'?watchAnalytics:createWatchAnalytics(state,persist);
function beginAnalytics(){if(state.selection)analytics.beginBroadcast({id:String(state.selection.updatedAt||'legacy-current'),title:state.selection.title,startedAt:state.selection.updatedAt});}
if(id==='2'){beginAnalytics();if(state.stopped)analytics.endBroadcast();}
const inputSecret=token(),inputPort=Number(process.env.SERVER_PORT||process.env.PORT||3000);let currentInput=null,lastInputError=null,inputProbeStats=[];
const mapInput=u=>'http://127.0.0.1:'+inputPort+'/_input?channel='+id+'&token='+inputSecret+'&url='+encodeURIComponent(u);
function safeSource(s){const u=new URL(s);if(u.protocol!=='https:'||u.username||u.password||!['smarter.majedcss.site','cloudfront-live.servers8.com'].includes(u.hostname))throw Error('مصدر غير مدعوم');return u.href;}
async function remote(url,options={}){const r=await fetch(url,{...options,redirect:'error',signal:AbortSignal.timeout(12000)});if(!r.ok)throw Error('تعذر الوصول إلى مصدر البث ('+r.status+')');return r;}
async function resolve(code){if(!/^[0-9]{1,32}$/.test(code))throw Error('أدخل كود البث الرقمي');const j=await(await remote('https://majed-koora.live/link/api/shortlink/'+code)).json();const d=j.data;if(!j.success||!d?.config?.url)throw Error('الكود غير متاح');if(d.expiresAt&&d.expiresAt<Date.now())throw Error('انتهت صلاحية كود البث');if(d.config.drmScheme)throw Error('حماية هذا البث غير مدعومة');safeSource(d.config.url);const headers={};for(const [key,name]of [['origin','Origin'],['referer','Referer'],['userAgent','User-Agent']])if(d.config[key]){if(/[\r\n]/.test(d.config[key]))throw Error('ترويسة غير صالحة');headers[name]=d.config[key];}const text=await(await remote(d.config.url,{headers})).text();if(!text.trimStart().startsWith('#EXTM3U'))throw Error('المصدر لم يرجع قائمة HLS');return {code,title:d.name||d.config.title||'دشوف مباشر',url:d.config.url,headers,expiresAt:d.expiresAt};}
console.log('[ffmpeg-runtime] '+JSON.stringify({bundled:ffmpegConfig.bundled,linuxGconvIsolation:ffmpegConfig.isolated}));
let probeWorker=null,videoInfo=null,failureCount=0,usingBackup=false,worker=null,retry=null,switching=false,status=state.stopped?'أوقف المضيف البث':state.selection?.kind==='helper'?'مصدر سابق ملغى؛ اختر مصدرًا مباشرًا':state.selection?.kind==='youtube'?'يوتيوب متاح داخل الموقع':'لم يتم اختيار بث',operation=0,ended=false,workerStarted=0,recoveryOperation=null,manifestFloor=Date.now();
function scheduleRecovery(){clearTimeout(retry);if(stopping||state.stopped)return;const delay=Math.min(15000,1000*2**Math.min(4,Math.max(0,failureCount-1)));status='نستعيد استقبال البث خلال '+Math.ceil(delay/1000)+' ثوانٍ';retry=setTimeout(recover,delay);}
async function halt(){
 clearTimeout(retry);probeWorker?.kill('SIGKILL');probeWorker=null;
 const p=worker;worker=null;
 const terminate=async()=>{if(!p||p.exitCode!==null||p.signalCode!==null||!p.pid)return;await new Promise(resolve=>{const timer=setTimeout(()=>p.kill('SIGKILL'),4000);timer.unref();p.once('close',()=>{clearTimeout(timer);resolve();});p.kill('SIGTERM');});};
 await Promise.all([terminate()]);
}
async function launch(source){if(state.stopped||stopping)return;ended=false;workerStarted=Date.now();currentInput=source;lastInputError=null;let lastManifest=null,manifestLoggedAt=0;currentInput.observeManifest=(text)=>{const info={segments:(text.match(/#EXTINF:/g)||[]).length,sequence:text.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/)?.[1]||null,endList:text.includes('#EXT-X-ENDLIST'),type:text.match(/#EXT-X-PLAYLIST-TYPE:([^\r\n]+)/)?.[1]||null};if(info.segments&&(Date.now()-manifestLoggedAt>30000||info.endList!==lastManifest?.endList)){console.log('[input-manifest] '+JSON.stringify(info));manifestLoggedAt=Date.now();}if(info.segments)lastManifest=info;};const launchOp=operation;await quality.configure(source).catch(()=>{if(currentInput===source)quality.reset(source);});
if(stopping||state.stopped||launchOp!==operation)return;const directHls=source.format==='hls';const info=directHls?null:await probe(source);if(stopping||state.stopped||launchOp!==operation)return;if(!directHls&&!info)throw Error('لم يمكن التحقق من مسار فيديو بدقة 1080p أو أقل؛ اختر مصدرًا متوافقًا');videoInfo=info;const args=['-hide_banner','-loglevel','error','-nostdin','-rw_timeout','15000000','-protocol_whitelist','http,tcp,crypto',...(directHls?[]:['-analyzeduration','2000000','-probesize','1048576']),...(source.format==='auto'?['-re']:['-f','hls',...ffmpegConfig.hlsInputArgs]),'-i',mapInput(source.url),'-map',directHls?'0:v:0':'0:'+videoInfo.index,'-map','0:a:0?','-c','copy','-f','hls','-hls_time','3','-hls_list_size','48','-hls_delete_threshold','6','-hls_flags','delete_segments+discont_start+omit_endlist+temp_file+program_date_time','-hls_start_number_source','epoch_us','-hls_segment_filename',path.join(media,'segment_%d.ts'),path.join(media,'dshoof.m3u8')];const p=spawn(ffmpeg,args,{stdio:['ignore','ignore','pipe'],env:ffmpegConfig.env});worker=p;console.log('[ingest] '+(directHls?'HLS direct start':'verified source start'));status='جاري استقبال المصدر';p.stderr.on('data',b=>{status='المصدر يحتاج مراجعة؛ نحاول استعادته';console.log('[ingest-error] '+String(b).replace(/https?:\/\/[^\s"']+/g,'[source-url]').slice(0,1500));});p.on('error',()=>{status='تعذر تشغيل FFmpeg على الاستضافة';});p.on('close',(exitCode,signal)=>{if(worker!==p||stopping)return;console.log('[ingest-close] '+JSON.stringify({exitCode,signal,seconds:Math.round((Date.now()-workerStarted)/1000),lastInputError,lastManifest}));worker=null;if(source.format==='auto'&&exitCode===0){ended=true;room.bump();status='انتهى الفيديو؛ يمكنك إعادة تشغيله';return;}if(Date.now()-workerStarted>60000)failureCount=0;failureCount++;pro.log('الخادم','توقف جلب الفيديو','محاولة '+failureCount).catch(()=>{});scheduleRecovery();});}
async function probe(source){lastInputError=null;inputProbeStats=[];return new Promise((resolve,reject)=>{const p=spawn(ffmpeg,['-hide_banner','-nostdin','-rw_timeout','10000000','-protocol_whitelist','http,tcp,crypto','-analyzeduration','2000000','-probesize','1048576',...(source.format==='hls'?['-f','hls',...ffmpegConfig.hlsInputArgs]:[]),'-i',mapInput(source.url),'-t','0','-f','null','-'],{stdio:['ignore','ignore','pipe'],env:ffmpegConfig.env});probeWorker=p;let result='',timedOut=false;const timer=setTimeout(()=>{timedOut=true;p.kill('SIGKILL');},45000);p.stderr.on('data',b=>{result=(result+b).slice(-65536);});p.on('error',reject);p.on('close',()=>{clearTimeout(timer);if(probeWorker===p)probeWorker=null;const info=parseVideoInfo(result);console.log('[video-probe] '+(info?info.width+'x'+info.height+' '+info.codec:lastInputError||(/extension|allowed_segment/i.test(result)?'HLS extension mismatch':/timed? out|timeout/i.test(result)?'source timeout':'no readable video stream')));if(info)return resolve(info);console.log('[video-input] '+JSON.stringify(inputProbeStats));console.log('[video-probe-detail] '+result.replace(/https?:\/\/[^\s\"']+/g,'[source-url]').slice(-4000).replace(/[\r\n]+/g,' | '));if(lastInputError)return reject(Error('تعذر فحص الفيديو: '+lastInputError));if(/extension.*(?:mismatch|not allowed)|not in allowed_segment_extensions/i.test(result))return reject(Error('رفض FFmpeg امتداد مقاطع المصدر؛ يلزم فحص توافق HLS'));if(timedOut||/timed? out|timeout/i.test(result))return reject(Error('انتهت مهلة قراءة مقاطع الفيديو من المصدر'));if(/Video:/i.test(result))return reject(Error('لم يتوفر مسار فيديو يمكن قراءته عند 1080p أو أقل'));return reject(Error('تعذر قراءة بيانات الفيديو من مقاطع المصدر؛ ليست مشكلة دقة مؤكدة'));});});}
async function prepare(input){if(input.kind==='helper')throw Error('تم إلغاء المشغّل المساعد؛ استخدم كود البث أو رابط الفيديو المباشر');if(input.kind==='youtube'&&/^[\w-]{11}$/.test(input.videoId||''))return {kind:'youtube',videoId:input.videoId,title:String(input.title||'يوتيوب · دشوف').slice(0,120)};if(['youtube','url','page','arena'].includes(input.kind)){const value=String(input.url||'').trim();const id=youtubeId(value);if(id)return {kind:'youtube',videoId:id,title:String(input.title||'يوتيوب · دشوف').slice(0,120)};if(input.kind==='youtube')throw Error('أدخل رابط فيديو يوتيوب صحيحًا');const direct=await inspectSource(value,{serverId:input.serverId});return {...direct,kind:'url',headers:direct.headers||{},title:String(input.title||direct.title||'فيديو مباشر · دشوف').slice(0,120)};}const code=String(input.code||'').trim().toLowerCase();return {...await resolve(code),kind:'code',format:'hls'};}
async function recover(){if(recoveryOperation===operation||probeWorker||worker||switching||stopping||state.stopped||!state.selection||['youtube','helper'].includes(state.selection.kind))return;const op=operation;recoveryOperation=op;try{const input=id==='1'&&failureCount>=2&&pro.state.backup?pro.state.backup:state.selection;usingBackup=input!==state.selection;const d=await prepare(input);if(!stopping&&!state.stopped&&op===operation&&!worker)await launch(d);}catch(e){if(op!==operation||stopping||state.stopped)return;failureCount++;status=e.message;await pro.log('الخادم','تعذر استعادة المصدر',usingBackup?'المصدر الاحتياطي':'المصدر الأساسي');if(op===operation&&!stopping&&!state.stopped)scheduleRecovery();}finally{if(recoveryOperation===op)recoveryOperation=null;}}
async function select(input){if(switching)throw Error('يجري تغيير البث؛ انتظر لحظة');switching=true;const op=++operation;try{const source=await prepare(input);if(op!==operation)throw Error('تم إلغاء التغيير');await halt();if(op!==operation)throw Error('تم إلغاء التغيير');manifestFloor=Date.now();await unlink(path.join(media,'dshoof.m3u8')).catch(e=>{if(e.code!=='ENOENT')throw e;});currentInput=null;quality.reset(null);failureCount=0;usingBackup=false;state.stopped=false;ended=false;state.selection={kind:source.kind,code:source.code,url:['url','helper'].includes(source.kind)?(source.sourcePage||source.url):undefined,embedUrl:source.kind==='helper'?source.embedUrl:undefined,format:source.format,videoId:source.videoId,serverId:source.serverId,serverName:source.serverName,title:source.title,updatedAt:Date.now(),expiresAt:source.expiresAt};beginAnalytics();state.history=[state.selection,...state.history.filter(x=>JSON.stringify([x.code,x.url,x.videoId,x.serverId])!==JSON.stringify([source.code,source.sourcePage||source.url,source.videoId,source.serverId]))].slice(0,10);await persist();room.bump();if(source.kind==='helper'){status='مشغّل مساعد داخل الموقع؛ الجودة والصوت من أدوات المصدر، دون M3U';}else if(source.kind==='youtube'){status='يوتيوب متاح داخل الموقع؛ رابط الرسيفر لا يعرض يوتيوب';}else await launch(source);}catch(e){status=e.message;if(op===operation&&!state.stopped)scheduleRecovery();throw e;}finally{if(op===operation)switching=false;}}
async function stopBroadcast(){operation++;state.stopped=true;analytics.endBroadcast();switching=false;ended=false;status='أوقف المضيف البث';room.bump();await persist();await halt();currentInput=null;quality.reset(null);}
async function live(){if(state.stopped||switching)return false;try{const s=await stat(path.join(media,'dshoof.m3u8'));return s.mtimeMs>=manifestFloor&&Date.now()-s.mtimeMs<(ended?90000:45000);}catch{return false;}}

async function input(req,res,url){if(!['127.0.0.1','::1','::ffff:127.0.0.1'].includes(req.socket.remoteAddress)||!equal(url.searchParams.get('token'),inputSecret)||!currentInput)return json(res,{error:'غير مسموح'},403);const headers={...currentInput.headers};if(req.headers.range&&/^bytes=\d+-\d*$/.test(req.headers.range))headers.Range=req.headers.range;const target=url.searchParams.get('url');const abort=new AbortController();res.once('close',()=>abort.abort());const {response,url:resolved}=await openPublic(target,headers,0,{signal:abort.signal});if(res.destroyed){response.destroy();return;}res.once('close',()=>response.destroy());const mime=String(response.headers['content-type']||'');const chunks=response[Symbol.asyncIterator]();let first=await chunks.next();let leading=first.done?Buffer.alloc(0):first.value;while(leading.length<16&&!first.done){first=await chunks.next();if(!first.done)leading=Buffer.concat([leading,first.value]);}const prefix=leading.toString('utf8').trimStart();if(prefix.startsWith('<')||/dash\+xml|(?:application|text)\/xml/i.test(mime)){response.destroy();throw Error('صيغة المصدر غير مدعومة');}const playlist=prefix.startsWith('#EXTM3U');if(playlist){const parts=[leading];let size=leading.length;if(size>2097152){response.destroy();throw Error('قائمة المصدر كبيرة جدًا');}for await(const c of chunks){size+=c.length;if(size>2097152){response.destroy();throw Error('قائمة المصدر كبيرة جدًا');}parts.push(c);}const manifest=Buffer.concat(parts).toString('utf8');currentInput?.observeManifest?.(manifest);if(probeWorker&&inputProbeStats.length<12)inputProbeStats.push({type:'playlist',segments:(manifest.match(/#EXTINF:/g)||[]).length,sequence:manifest.match(/#EXT-X-MEDIA-SEQUENCE:(\d+)/)?.[1]||null});res.setHeader('Content-Type','application/vnd.apple.mpegurl');return res.end(rewriteInput(capMaster(manifest,resolved,1080,true),resolved,mapInput));}if(probeWorker&&inputProbeStats.length<12)inputProbeStats.push({type:'media',mime,bytes:leading.length,ts:leading[0]===0x47});res.statusCode=response.statusCode;for(const name of ['content-type','content-length','content-range','accept-ranges'])if(response.headers[name])res.setHeader(name,response.headers[name]);res.on('close',()=>response.destroy());const output=Readable.from((async function*(){if(leading.length)yield leading;for await(const chunk of chunks)yield chunk;})());output.on('error',()=>res.destroy());response.on('error',()=>res.destroy());output.pipe(res);return;}
async function maintain(){
 try{
  const list=await readdir(media);
  let playlistReadable=false;
  let referenced=new Set();
  try{
   const playlist=await readFile(path.join(media,'dshoof.m3u8'),'utf8');
   referenced=new Set([...playlist.matchAll(/^segment_\d+\.ts$/gm)].map(match=>match[0]));
   playlistReadable=true;
  }catch{ // A missing playlist must never trigger indiscriminate deletion.
  }
  const stats=[];
  let bytes=0;
  for(const f of list)if(/^segment_\d+\.ts$/.test(f)){
   try{
    const item=await stat(path.join(media,f));
    stats.push({f,...item});bytes+=item.size;
   }catch(error){if(error.code!=='ENOENT')throw error;}
  }
  const now=Date.now();
  // An active manifest must never reference a segment deleted by housekeeping.
  for(const item of stats.sort((a,b)=>a.mtimeMs-b.mtimeMs)){
   if(!playlistReadable||referenced.has(item.f))continue;
   if(bytes<=256*1024*1024&&now-item.mtimeMs<=240000)continue;
   try{await unlink(path.join(media,item.f));bytes-=item.size;}
   catch(error){if(error.code!=='ENOENT')throw error;}
  }
  if(worker&&!switching&&!state.stopped){
   let latest=workerStarted;
   try{latest=Math.max(latest,(await stat(path.join(media,'dshoof.m3u8'))).mtimeMs);}catch{}
   if(now-latest>60000){
    await halt();status='لم تصل مقاطع حديثة؛ نحاول استعادة المصدر';recover();
   }
  }
 }catch(error){console.log('[media-cleanup] '+String(error.code||error.name||'error'));}
}
return {state,quality,analytics,select,stopBroadcast,live,input,halt,recover,maintain,prepare, get info(){return {selection:state.selection,stopped:!!state.stopped,ended,status,history:state.history,videoInfo,usingBackup,failures:failureCount};},async close(){operation++;await halt();quality.reset(null);if(id==='2')await analytics.close();}};
}
const channels=[await createBroadcast('1',state,media),await createBroadcast('2',state.secondChannel,path.join(data,'media-2'))];
const channelById=id=>{if(!['1','2'].includes(String(id||'1')))throw Error('اختر القناة الأولى أو الثانية');return channels[Number(id||1)-1];};
const select=b=>channelById(b.channel).select(b),stopBroadcast=()=>channels[0].stopBroadcast();
await persist();
async function body(req){const chunks=[];let size=0;for await(const b of req){size+=b.length;if(size>8192)throw Error('الطلب كبير');chunks.push(b);}return JSON.parse(Buffer.concat(chunks).toString('utf8')||'{}');}
function json(res,obj,status=200){res.writeHead(status,{'Content-Type':'application/json; charset=utf-8'});res.end(JSON.stringify(obj));}
function publicOrigin(req){const host=req.headers.host;if(!host||!/^([a-z0-9.-]+|\[[a-f0-9:]+\])(:\d+)?$/i.test(host))throw Error('عنوان غير صالح');return (process.env.PUBLIC_URL||((req.headers['x-forwarded-proto']==='https'?'https':'http')+'://'+host)).replace(/\/$/,'');}
const cookieOptions=origin=>'; HttpOnly; SameSite=Lax; Path=/'+(origin.startsWith('https:')?'; Secure':'');
const staticFiles={'/club-pages.css':'club-pages.css','/club-mark.svg':'club-mark.svg','/club-icons.svg':'club-icons.svg','/club-stadium.webp':'club-stadium.webp','/club-crowd.webp':'club-crowd.webp','/club-arabic.woff2':'club-arabic.woff2','/club-licenses.md':'club-licenses.md','/dshoof-logo-small.webp':'dshoof-logo-small.webp','/dshoof-logo.png':'dshoof-logo.png','/':'index.html','/watch':'index.html','/app.js':'app.js','/style.css':'style.css','/hls.min.js':'hls.min.js','/favicon.svg':'favicon.svg','/manifest.webmanifest':'manifest.webmanifest','/beta.js':'beta.js','/pro.js':'pro.js','/pro.css':'pro.css','/sw.js':'sw.js','/offline.html':'offline.html','/remote':'remote.html','/remote.js':'remote.js','/icon-192.png':'icon-192.png','/icon-512.png':'icon-512.png'};
const segmentCache=createSegmentCache({maxBytes:48*1024*1024,ttl:120000});
const staticCache=new Map(),apiRates=new Map();
const server=http.createServer(async(req,res)=>{
 res.setHeader('Cache-Control','no-store');res.setHeader('X-Content-Type-Options','nosniff');res.setHeader('Referrer-Policy','no-referrer');res.setHeader('X-Frame-Options','DENY');res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=(self)');res.setHeader('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; media-src 'self' blob:; worker-src 'self' blob:; connect-src 'self'; frame-src 'self' https://www.youtube-nocookie.com; frame-ancestors 'none'; base-uri 'none'");
 try{
 if(!['GET','HEAD','POST'].includes(req.method)){res.setHeader('Allow','GET, HEAD, POST');return json(res,{error:'طريقة الطلب غير متاحة'},405);}
 if(!req.url?.startsWith('/')||req.url.startsWith('//'))return json(res,{error:'مسار الطلب غير صالح'},400);
 const origin=publicOrigin(req),url=new URL(req.url,origin);let p=url.pathname;let activeChannel=channelById(url.searchParams.get('channel'));const scoped=p.match(/^\/channels\/(1|2)(\/.*)$/);if(scoped){activeChannel=channelById(scoped[1]);p=scoped[2];}const channelId=String(channels.indexOf(activeChannel)+1),channelBase=origin+(channelId==='1'?'':'/channels/'+channelId),quality=activeChannel.quality;
 if(p.startsWith('/api/')){const key=req.socket.remoteAddress||'unknown',now=Date.now(),v=apiRates.get(key);if(v&&now-v.at<10000){if(++v.count>480)return json(res,{error:'طلبات كثيرة، حاول بعد لحظات'},429);}else {if(apiRates.size>=2000)apiRates.delete(apiRates.keys().next().value);apiRates.set(key,{at:now,count:1});}if(apiRates.size>2000)for(const[k,v]of apiRates)if(now-v.at>10000)apiRates.delete(k);}
 if(req.method==='POST'){
  if(req.headers.origin!==origin)return json(res,{error:'طلب غير مسموح'},403);
  const b=await body(req);if(b.channel===undefined&&scoped)b.channel=channelId;
  if(p==='/api/login'){room.limit(req.socket.remoteAddress,'login',700);if(!equal(b.key,state.owner))return json(res,{error:'رابط إدارة غير صالح'},403);res.setHeader('Set-Cookie','dshoof_owner='+room.ownerSession()+cookieOptions(origin).replace('SameSite=Lax','SameSite=Strict')+'; Max-Age=43200');return json(res,{ok:true});}
  if(p==='/api/join'){const joined=await room.join(b,req);res.setHeader('Set-Cookie','dshoof_member='+joined.sessionCookie+cookieOptions(origin)+'; Max-Age=31536000');return json(res,{ok:true,member:joined.member});}
  if(p==='/api/remote')return json(res,pro.remote({id:'remote'},b));
  const a=access(req,url);if(!a||a.limited)return json(res,{error:a?.reason||'انتهت صلاحية المشاهدة'},403);
  if(p.startsWith('/api/pro/')){const action=p.slice(9);room.limit(a.id,p,300);if(action==='voice-poll')return json(res,{id:a.connection||a.id,muted:true,peers:[],signals:[],sequence:0});if(['settings','backup','schedule'].includes(action)&&!a.owner)return json(res,{error:'إعدادات الخدمة للمالك فقط'},403);
   if(action==='settings'){await pro.settings(b);return json(res,{ok:true});}
   if(action==='backup'){if(b.url)await inspectSource(b.url);await pro.backup(b);return json(res,{ok:true});}
   if(action==='schedule'){if(b.url)await inspectSource(b.url);await pro.schedule(b);return json(res,{ok:true});}
   if(action==='marker'){await pro.marker(a,b);return json(res,{ok:true});}
   if(action==='board'){await pro.drawing(a,b);return json(res,{ok:true});}
   if(action==='sync'){await pro.sync(a,b);return json(res,{ok:true});}
   if(action==='pair')return json(res,pro.pair(a));
   if(action==='remote')return json(res,{command:pro.remote(a,b)});
   return json(res,{error:'إجراء غير معروف'},404);
  }
  if(p==='/api/profile'){await room.profile(a,b);return json(res,{ok:true,room:room.snapshot(access(req,url))});}
  if(p==='/api/typing'){room.limit(a.id,'typing',2000);room.type(a);return json(res,{ok:true});}
  if(p==='/api/chat/pin'){room.pin(a,b);await persist();return json(res,{ok:true});}
  if(p==='/api/chat'){room.chat(a,b);await persist();return json(res,{ok:true,room:room.snapshot(access(req,url))});}
  if(p==='/api/react'){if(room.react(a,b))pro.reaction(b.type);await persist();return json(res,{ok:true});}
  if(p==='/api/privacy'){room.privacy(a,b);await persist();return json(res,{ok:true});}
  if(p==='/api/report'){room.report(a,b,viewerInfo(req,b.clientInfo));await persist();const c=channelById(b.channel);if(!c.state.stopped)c.analytics.report(a,b);return json(res,{ok:true});}
  if(p==='/api/poll'&&b.action==='vote'){room.polling(a,b);await persist();return json(res,{ok:true});}
  const delegated=a.role==='stream'&&['/api/select','/api/stop','/api/resume','/api/source-options'].includes(p)||a.role==='moderator'&&p==='/api/chat/clear';if(!owner(req)&&!delegated)return json(res,{error:'هذا الإجراء لمالك دشوف فقط'},403);await pro.log(a.name,p);
  if(p==='/api/stream-profile')return json(res,{error:'أزيلت أوضاع الضغط؛ البث بجودة المصدر'},410);
  if(p==='/api/channel-name'){const c=channelById(b.channel);const name=String(b.name||'').trim();if(!name||name.length>60)throw Error('اسم القناة مطلوب وبحد أقصى 60 حرفًا');state.channelNames[channels.indexOf(c)]=name;await persist();room.bump();return json(res,{ok:true});}
  if(p==='/api/source-options'){room.limit(a.id,'source-options',1000);return json(res,await discoverMajedServers(String(b.url||'').trim()));}
  if(p==='/api/select'){state.activeSchedule=null;await select(b);return json(res,{ok:true,selection:channelById(b.channel).state.selection});}
  if(p==='/api/stop'){state.activeSchedule=null;await channelById(b.channel).stopBroadcast();return json(res,{ok:true});}
  if(p==='/api/resume'){state.activeSchedule=null;const c=channelById(b.channel);if(!c.state.selection)throw Error('اختر مصدرًا أولًا');await c.select(c.state.selection);return json(res,{ok:true});}
  if(p==='/api/invites')return json(res,await room.invite(b,origin));
  if(p==='/api/revoke'){await room.moderate(b);return json(res,{ok:true,room:room.snapshot(access(req,url))});}
  if(p==='/api/settings'){await room.settings(b);return json(res,{ok:true,room:room.snapshot(access(req,url))});}
  if(p==='/api/members'){await room.manageMember(a,b);return json(res,{ok:true,room:room.snapshot(access(req,url))});}
  if(p==='/api/chat/clear'){room.clear(b);await persist();return json(res,{ok:true});}
  if(p==='/api/poll'){room.polling(a,b);await persist();return json(res,{ok:true});}
  if(p==='/api/logout'){room.logout(req);res.setHeader('Set-Cookie','dshoof_owner=; Max-Age=0; Path=/; HttpOnly; SameSite=Strict');return json(res,{ok:true});}
  return json(res,{error:'إجراء غير متاح'},404);
 }
 if(req.method!=='GET'&&req.method!=='HEAD')return json(res,{error:'طريقة غير مدعومة'},405);
 if(p==='/helper-frame'||p==='/helper-preview')return json(res,{error:'المشغّل المساعد ملغى'},410);
if(p==='/_input'){await channelById(url.searchParams.get('channel')).input(req,res,url);return;}

 if(p==='/api/events'){if(req.method!=='GET')return json(res,{error:'طريقة غير متاحة'},405);await chatEvents.handle(req,res,{access:()=>access(req,url),snapshot:(a,since)=>room.snapshot(a,since),subscribe:fn=>room.subscribe(fn)});return;}
 if(p==='/api/pro/qr'){const a=access(req,url);if(!a||a.limited)return json(res,{error:'غير مسموح'},403);pro.remote(a,{code:url.searchParams.get('code'),action:'read'});let qr;try{qr=createRequire(import.meta.url)('qrcode');}catch{return json(res,{error:'لم تثبت حزمة QR بعد'},503);}res.setHeader('Content-Type','image/svg+xml');return res.end(await qr.toString(origin+'/remote?code='+url.searchParams.get('code'),{type:'svg',width:220}));}
 if(p==='/api/pro'){const a=access(req,url);if(!a||a.limited)return json(res,{error:'دعوة غير صالحة'},403);return json(res,{...pro.publicState(a),role:a.owner?'owner':a.role||'viewer',videoInfo:activeChannel.info.videoInfo,maxHeight:1080,usingBackup:activeChannel.info.usingBackup,failures:activeChannel.info.failures,...(a.owner?{metrics:{segmentCache:segmentCache.stats(),rss:process.memoryUsage().rss,uptime:process.uptime(),viewers:room.active.size,reports:room.admin(origin).flatMap(x=>x.connections.map(c=>c.report).filter(Boolean))}}:{})});}
 const epg=p.match(/^\/p\/([\w-]{12,64})\/epg\.xml$/);if(epg){url.searchParams.set('key',epg[1]);const a=room.access(req,url,{legacy:true});if(!a||a.limited||a.member)return json(res,{error:'غير مسموح'},403);res.setHeader('Content-Type','application/xml; charset=utf-8');return res.end(epgXML(pro.state.schedules));}
 if(p==='/healthz')return json(res,{status:'ok',brand:'دشوف',streamReady:(await Promise.all(channels.map(c=>c.live()))).some(Boolean),version:'3.5.0',release:process.env.DSHOOF_RELEASE||'3.4.0-dual-channel.1',bootId:process.env.DSHOOF_BOOT_ID||null});
 if(p==='/api/export'){if(!owner(req))return json(res,{error:'للمالك فقط'},403);res.setHeader('Content-Disposition','attachment; filename="dshoof-private-backup.json"');return json(res,state);}
 if(p==='/api/status'){
  const a=access(req,url),allowed=!!a&&!a.limited,isOwner=owner(req),adminMembers=isOwner?room.admin(origin):[],cs=activeChannel.state,ci=activeChannel.info;const channelListStatus=allowed?await Promise.all(channels.map(async(c,i)=>({id:String(i+1),name:state.channelNames[i],ready:!c.state.stopped&&(c.state.selection?.kind==='youtube'||c.quality.available()||await c.live()),stopped:!!c.state.stopped,title:c.state.selection?.title||''}))):[];
  return json(res,{version:'3.5.0',channel:channelId,channelName:state.channelNames[Number(channelId)-1],channels:channelListStatus,canControl:isOwner,authenticated:!!a,registrationRequired:!a,profile:a?.member?{id:a.id,username:a.username,name:a.name,avatar:a.avatar}:isOwner?{id:'owner',name:a.name,avatar:a.avatar||'purple'}:null,publicRoomURL:origin+'/',authorized:allowed,limited:!!a?.limited,stopped:!!cs.stopped,ended:ci.ended,qualities:allowed?quality.list():[],adaptive:allowed&&quality.available(),qualityNote:cs.selection?.kind==='helper'?'البث المساعد يعمل داخل الموقع فقط؛ الجودة والصوت من المشغّل الأصلي ولا يتوفر M3U لهذا الخيار':'الجودات حسب المصدر؛ يحتفظ دشوف بنافذة بث بإعدادات التخزين السابقة لكل قناة دون ضغط',selection:allowed?(isOwner?cs.selection:cs.selection?{title:cs.selection.title,kind:cs.selection.kind,videoId:cs.selection.videoId,updatedAt:cs.selection.updatedAt}:null):null,ready:allowed&&!cs.stopped&&(cs.selection?.kind==='youtube'||quality.available()||await activeChannel.live()),relayReady:allowed&&!cs.stopped&&await activeChannel.live(),status:allowed?ci.status:a?.reason||'اختر اسم المستخدم واسمك للانضمام إلى دشوف',room:allowed?room.snapshot(a,url.searchParams.get('since')):null,...(isOwner?{playlist:origin+'/p/'+state.playlistAlias+(channelId==='1'?'':'/channel/2')+'.m3u',channelPlaylists:channels.map((c,i)=>({id:String(i+1),name:state.channelNames[i],url:origin+'/p/'+state.playlistAlias+(i?'/channel/2':'')+'.m3u'})),qualityPlaylists:[{id:'highest',label:'النت السريع — السيرفرات الأسرع'},{id:'auto',label:'تلقائي حسب الاتصال'},...quality.list()].map(q=>({...q,url:origin+'/p/'+state.playlistAlias+'/'+q.id+'.m3u'+(channelId==='2'?'?channel=2':'')})),allQualitiesPlaylist:origin+'/p/'+state.playlistAlias+'/all.m3u'+(channelId==='2'?'?channel=2':''),legacyPlaylist:origin+'/dshoof.m3u?key='+state.viewer,history:cs.history,invites:adminMembers.filter(x=>x.kind!=='member'),members:adminMembers.filter(x=>x.kind==='member').map(member=>({...member,analytics:activeChannel.analytics.perMember(member.id)})),analytics:activeChannel.analytics.summary(),viewers:room.presence?.size??room.active.size,watching:room.active.size,maxViewers:state.settings.maxViewers,epg:origin+'/p/'+state.playlistAlias+'/epg.xml',uptime:Math.round(process.uptime())}:{})});
 }
 const channelPlaylist=p.match(/^\/p\/([\w-]{12})\/channel\/(1|2)\.m3u$/);if(channelPlaylist){url.searchParams.set('key',channelPlaylist[1]);res.writeHead(307,{Location:origin+'/channels/'+channelPlaylist[2]+'/dshoof.m3u?key='+encodeURIComponent(channelPlaylist[1])});return res.end();}
 if(/^\/(?:weak|emergency)\//.test(p))return json(res,{error:'أزيل هذا المسار؛ استخدم رابط القناة الأساسي'},410);
 const namedPlaylist=p.match(/^\/p\/([\w-]{12})\/(auto|highest|all|\d{2,4}p)\.m3u$/);
 if(namedPlaylist){url.searchParams.set('key',namedPlaylist[1]);url.searchParams.set('quality',namedPlaylist[2]);p='/dshoof.m3u';}
 const qualityPath=p.match(/^\/quality\/(auto|\d{2,4}p)\.m3u8$/),mediaPath=p.match(/^\/quality\/media\/([a-f0-9]{24})$/);
 if(qualityPath||mediaPath){const a=room.access(req,url,{lease:true,legacy:url.searchParams.has('key')});if(!a||a.limited)return json(res,{error:a?.reason||'انتهت صلاحية المشاهدة'},403);if(activeChannel.state.stopped)return json(res,{error:'أوقف المضيف البث'},410);if(['youtube','helper'].includes(activeChannel.state.selection?.kind))return json(res,{error:'الجودة من أدوات المشغّل داخل الموقع فقط'},409);
 if(mediaPath){await quality.serve(req,res,mediaPath[1],channelBase,a.key);return;}
 const q=qualityPath[1];if(!quality.available()){if(q!=='auto')return json(res,{error:'هذه الدقة غير متاحة من المصدر الحالي'},404);res.writeHead(307,{Location:channelBase+'/live/dshoof.m3u8'+(a.key?'?key='+encodeURIComponent(a.key):'')});return res.end();}
 if(q!=='auto'&&!quality.list().some(x=>x.id===q))return json(res,{error:'هذه الدقة غير متاحة من المصدر الحالي'},404);
 res.setHeader('Content-Type','application/vnd.apple.mpegurl');return res.end(quality.masterPlaylist(q==='auto'?undefined:Number(q.slice(0,-1)),channelBase,a.key));
 }
 const shortPlaylist=p.match(/^\/p\/([\w-]{12})\.m3u$/);if(shortPlaylist){url.searchParams.set('key',shortPlaylist[1]);p='/dshoof.m3u';}
 if(p==='/dshoof.m3u'||p==='/live/dshoof.m3u8'||/^\/live\/segment_\d+\.ts$/.test(p)){
  const a=room.access(req,url,{lease:true,legacy:url.searchParams.has('key')});if(!a)return json(res,{error:'سجّل اسمك أولًا للانضمام إلى المشاهدة'},403);if(a.limited)return json(res,{error:a.reason},429);
  if(activeChannel.state.selection?.kind==='helper')return json(res,{error:'البث المساعد يعمل داخل الموقع فقط؛ لا يوفر رابط M3U'},409);
  if(p==='/dshoof.m3u'){if(a.member)return json(res,{error:'شارك رابط الموقع العام؛ روابط الأجهزة الخاصة للمالك فقط'},403);const selected=url.searchParams.get('quality')||'highest',available=[{id:'highest',label:'النت السريع — السيرفرات الأسرع'},{id:'auto',label:'تلقائي'},...quality.list()];const chosen=selected==='all'?available:available.filter(x=>x.id===selected);if(!chosen.length)return json(res,{error:'هذه الدقة غير متاحة في المصدر الحالي'},404);const entries=chosen.map(q=>({label:q.label,url:channelBase+(q.id==='highest'?'/live/dshoof.m3u8':'/quality/'+q.id+'.m3u8')+'?key='+encodeURIComponent(a.key)}));res.setHeader('Content-Type','audio/x-mpegurl; charset=utf-8');res.setHeader('Content-Disposition','attachment; filename="dshoof-'+selected+'.m3u"');return res.end(channelList(state.channelNames[Number(channelId)-1],entries).replace('#EXTM3U','#EXTM3U x-tvg-url="'+origin+'/p/'+a.key+'/epg.xml"').replaceAll('#EXTINF:-1 ','#EXTINF:-1 tvg-id="dshoof" tvg-logo="'+origin+'/dshoof-logo.png?v=19" '));}
  if(activeChannel.state.stopped)return json(res,{error:'أوقف المضيف البث'},410);
  if(p.endsWith('.m3u8')){if(activeChannel.state.selection?.kind==='youtube')return json(res,{error:'فيديو يوتيوب متاح في الموقع فقط، وليس عبر M3U'},409);if(!await activeChannel.live())return json(res,{error:activeChannel.info.status},503);let text=await readFile(path.join(channelId==='1'?media:path.join(data,'media-2'),'dshoof.m3u8'),'utf8');const lines=text.split('\n');let removed=0;for(let i=0;i<lines.length;i++)if(/^segment_\d+\.ts$/.test(lines[i])){try{await stat(path.join(channelId==='1'?media:path.join(data,'media-2'),lines[i]));}catch{lines[i]='';if(lines[i-1]?.startsWith('#EXT-X-PROGRAM-DATE-TIME'))lines[i-1]='';for(let j=i-1;j>=0&&j>=i-4;j--)if(lines[j]?.startsWith('#EXTINF:')){lines[j]='';break;}removed++;}}text=lines.filter(Boolean).join('\n').replace(/#EXT-X-MEDIA-SEQUENCE:(\d+)/,(_,n)=>'#EXT-X-MEDIA-SEQUENCE:'+(BigInt(n)+BigInt(removed)));text=text.split('\n').map(line=>/^segment_\d+\.ts$/.test(line)?channelBase+'/live/'+line+(a.key?'?key='+encodeURIComponent(a.key):''):line).join('\n');if(activeChannel.info.ended&&!text.includes('#EXT-X-ENDLIST'))text+='\n#EXT-X-ENDLIST\n';res.setHeader('Content-Type','application/vnd.apple.mpegurl');return res.end(text);}
  const f=path.join(channelId==='1'?media:path.join(data,'media-2'),path.basename(p)),s=await stat(f);res.setHeader('Content-Type','video/mp2t');res.setHeader('Content-Length',s.size);if(req.method==='HEAD')return res.end();const cached=await segmentCache.get(f+':'+s.mtimeMs+':'+s.size,s.size,()=>readFile(f));if(cached)return res.end(cached);const stream=createReadStream(f);res.once('close',()=>stream.destroy());stream.on('error',()=>res.destroy()).pipe(res);return;
 }
 const invitePath=p.match(/^\/w\/([\w-]{12})$/);if(invitePath)url.searchParams.set('key',invitePath[1]);
 if((p==='/watch'&&url.searchParams.has('key'))||invitePath){req.viewerDevice=cookies(req).dshoof_device||token();const a=access(req,url);if(a&&!a.limited){res.setHeader('Set-Cookie',['dshoof_viewer='+a.key+cookieOptions(origin),'dshoof_device='+req.viewerDevice+cookieOptions(origin)]);res.writeHead(303,{Location:'/watch'});return res.end();}p='/watch';}
 const f=staticFiles[p];if(!f)return json(res,{error:'غير موجود'},404);if(!staticCache.has(f))staticCache.set(f,await readFile(path.join(root,'public',f)));let bytes=staticCache.get(f);
 const accept=String(req.headers['accept-encoding']||'');const compressible=/\.(?:js|css|html|svg|webmanifest)$/.test(f)&&bytes.length>1024;
 const encoding=compressible&&/(?:^|,)\s*br\s*(?:,|$)/.test(accept)?'br':compressible&&/(?:^|,)\s*gzip\s*(?:,|$)/.test(accept)?'gzip':null;
 if(compressible)res.setHeader('Vary','Accept-Encoding');
 if(encoding){const variant=f+':'+encoding;if(!staticCache.has(variant))staticCache.set(variant,await (encoding==='br'?compressBrotli(bytes,{params:{[zlibConstants.BROTLI_PARAM_QUALITY]:4}}):compressGzip(bytes,{level:6})));bytes=staticCache.get(variant);res.setHeader('Content-Encoding',encoding);}
 res.setHeader('Content-Length',bytes.length);res.setHeader('Content-Type',f.endsWith('.js')?'text/javascript; charset=utf-8':f.endsWith('.css')?'text/css':f.endsWith('.webp')?'image/webp':f.endsWith('.png')?'image/png':f.endsWith('.svg')?'image/svg+xml':f.endsWith('.woff2')?'font/woff2':f.endsWith('.md')?'text/plain; charset=utf-8':f.endsWith('.webmanifest')?'application/manifest+json':'text/html; charset=utf-8');if(p!=='/'&&p!=='/watch'){res.setHeader('Cache-Control',p==='/sw.js'?'no-cache':'public, max-age=3600');const etag='"'+hash(bytes)+'"';res.setHeader('ETag',etag);if(req.headers['if-none-match']===etag){res.writeHead(304);return res.end();}}if(req.method==='HEAD')return res.end();res.end(bytes);
 }catch(e){if(req.url?.split('?')[0]==='/_input')console.log('[input-error] '+String(e.message).replace(/https?:\/\/[^\s"']+/g,'[source-url]').slice(0,240)); if(res.destroyed)return;if(res.headersSent){res.destroy();return;}json(res,{error:e.code==='ENOENT'?'المحتوى غير متاح':e.message},e.code==='ENOENT'?404:e.httpStatus===403?403:req.url?.split('?')[0]==='/_input'?502:400);}
});
server.requestTimeout=20000;server.headersTimeout=15000;
server.listen(inputPort,process.env.BIND_HOST||'0.0.0.0',()=>console.log('Dshoof Player 3.5 listening; private owner access is in data/owner-link.txt'));
for(const c of channels)if(c.state.selection&&!c.state.stopped)c.recover();
setInterval(()=>Promise.all(channels.map(c=>c.maintain())).catch(()=>{}),15000).unref();
let schedulerBusy=false;setInterval(async()=>{if(schedulerBusy)return;schedulerBusy=true;try{const now=Date.now();for(const item of pro.state.schedules){if(item.done)continue;if(now>=item.end){if(item.started&&state.activeSchedule===item.id){await stopBroadcast();state.activeSchedule=null;}item.done=true;await persist();}else if(!item.started&&now>=item.start){item.started=true;state.activeSchedule=item.id;await persist();try{await select(item.source);await pro.log('الجدولة','تشغيل موعد',item.title);}catch{await pro.log('الجدولة','تعذر تشغيل الموعد',item.title);}}}pro.cleanHistory();}catch{}finally{schedulerBusy=false;}},15000).unref();

for(const sig of ['SIGTERM','SIGINT'])process.on(sig,async()=>{stopping=true;chatEvents.close();await Promise.all(channels.map(c=>c.close()));await watchAnalytics.close().catch(()=>{console.error('[watch-analytics] Unable to flush recent counters');});server.close(()=>process.exit(0));setTimeout(()=>process.exit(0),2000).unref();});

